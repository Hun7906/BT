package bai43;

public class Main {
    public static void main(String[] args) {
        Point2D point2D = new Point2D(3.5f, 4.5f);
        System.out.println("Point2D: " + point2D);

        Point3D point3D = new Point3D(3.5f, 4.5f, 5.5f);
        System.out.println("Point3D: " + point3D);
    }
}