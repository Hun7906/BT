package bai46;

public class Mammal extends Animal {
    public Mammal(String name) {
        super(name);
    }

    @Override
    public String toString() {
        return "Mammal: Mamaml [" + super.toString() + "]";
    }
}