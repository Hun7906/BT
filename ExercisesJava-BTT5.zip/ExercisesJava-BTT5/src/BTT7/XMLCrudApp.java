package BTT7;

import org.w3c.dom.*;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class XMLCrudApp {
    private JFrame frame;
    private JTextField txtElementName, txtElementValue;
    private JTextArea txtOutput;
    private Document doc;
    private File xmlFile = new File("data.xml");

    public XMLCrudApp() {
        frame = new JFrame("XML CRUD Application");
        frame.setSize(600, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        txtElementName = new JTextField(10);
        txtElementValue = new JTextField(10);
        JButton btnAdd = new JButton("Create");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnSave = new JButton("Save XML");
        JButton btnLoad = new JButton("Load XML");
        JButton btnMerge = new JButton("Merge XML");
        JButton btnLoadMerged = new JButton("Load Merged XML");
        txtOutput = new JTextArea(15, 50);

        frame.add(new JLabel("Element Name:"));
        frame.add(txtElementName);
        frame.add(new JLabel("Element Value:"));
        frame.add(txtElementValue);
        frame.add(btnAdd);
        frame.add(btnUpdate);
        frame.add(btnDelete);
        frame.add(btnSave);
        frame.add(btnLoad);
        frame.add(btnMerge);
        frame.add(btnLoadMerged);
        frame.add(new JScrollPane(txtOutput));

        btnAdd.addActionListener(e -> createElement());
        btnUpdate.addActionListener(e -> updateElement());
        btnDelete.addActionListener(e -> deleteElement());
        btnSave.addActionListener(e -> saveXML());
        btnLoad.addActionListener(e -> loadXML());
        btnMerge.addActionListener(e -> mergeXMLFiles());
        btnLoadMerged.addActionListener(e -> loadMergedXML());

        initXML();
        frame.setVisible(true);
    }

    private void initXML() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            if (xmlFile.exists()) {
                doc = builder.parse(xmlFile);
            } else {
                doc = builder.newDocument();
                doc.appendChild(doc.createElement("root"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createElement() {
        String name = txtElementName.getText();
        String value = txtElementValue.getText();
        if (name.isEmpty() || value.isEmpty()) return;
        Element newElement = doc.createElement(name);
        newElement.setTextContent(value);
        doc.getDocumentElement().appendChild(newElement);
        txtOutput.append("Created: <" + name + ">" + value + "</" + name + ">\n");
    }

    private void updateElement() {
        String name = txtElementName.getText();
        String value = txtElementValue.getText();
        if (name.isEmpty() || value.isEmpty()) return;
        NodeList list = doc.getElementsByTagName(name);
        if (list.getLength() > 0) {
            list.item(0).setTextContent(value);
            txtOutput.append("Updated: <" + name + ">" + value + "</" + name + ">\n");
        }
    }

    private void deleteElement() {
        String name = txtElementName.getText();
        if (name.isEmpty()) return;
        NodeList list = doc.getElementsByTagName(name);
        if (list.getLength() > 0) {
            Node node = list.item(0);
            doc.getDocumentElement().removeChild(node);
            txtOutput.append("Deleted: <" + name + ">\n");
        }
    }

    private void saveXML() {
        try {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(new DOMSource(doc), new StreamResult(xmlFile));
            txtOutput.append("XML Saved!\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadXML() {
        try {
            txtOutput.setText("");
            NodeList list = doc.getDocumentElement().getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                if (list.item(i) instanceof Element) {
                    Element el = (Element) list.item(i);
                    txtOutput.append("<" + el.getTagName() + ">" + el.getTextContent() + "</" + el.getTagName() + ">\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mergeXMLFiles() {
        try {
            List<File> xmlFiles = List.of(new File("data1.xml"), new File("data2.xml"));
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document mergedDoc = builder.newDocument();
            Element root = mergedDoc.createElement("mergedRoot");
            mergedDoc.appendChild(root);

            for (File file : xmlFiles) {
                if (file.exists()) {
                    Document tempDoc = builder.parse(file);
                    NodeList list = tempDoc.getDocumentElement().getChildNodes();
                    for (int i = 0; i < list.getLength(); i++) {
                        Node node = mergedDoc.importNode(list.item(i), true);
                        root.appendChild(node);
                    }
                }
            }
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(new DOMSource(mergedDoc), new StreamResult(new File("merged.xml")));
            txtOutput.append("XML Merged!\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadMergedXML() {
        try {
            File mergedFile = new File("merged.xml");
            if (!mergedFile.exists()) return;
            txtOutput.setText("");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document mergedDoc = builder.parse(mergedFile);
            NodeList list = mergedDoc.getDocumentElement().getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                if (list.item(i) instanceof Element) {
                    Element el = (Element) list.item(i);
                    txtOutput.append("<" + el.getTagName() + ">" + el.getTextContent() + "</" + el.getTagName() + ">\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(XMLCrudApp::new);
    }
}
