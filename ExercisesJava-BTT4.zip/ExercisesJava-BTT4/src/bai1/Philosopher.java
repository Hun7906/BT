package bai1;
import java.util.concurrent.Semaphore;

class Philosopher extends Thread {
    private int id;
    private Semaphore leftChopstick;
    private Semaphore rightChopstick;
    private Semaphore table; // Kiểm soát số triết gia vào bàn
    private static final int MAX_EAT_TIMES = 5; // Mỗi triết gia ăn 5 lần
    private int eatCount = 0; // Số lần đã ăn

    public Philosopher(int id, Semaphore leftChopstick, Semaphore rightChopstick, Semaphore table) {
        this.id = id;
        this.leftChopstick = leftChopstick;
        this.rightChopstick = rightChopstick;
        this.table = table;
    }

    private void think() {
        System.out.println("Triết gia " + id + " đang suy nghĩ...");
        try {
            Thread.sleep((long) (Math.random() * 1000)); // Suy nghĩ ngẫu nhiên
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void eat() {
        System.out.println("Triết gia " + id + " đang ăn (lần " + (eatCount + 1) + ")...");
        try {
            Thread.sleep(1000); // Ăn trong 3 giây
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        eatCount++;
    }

    public void run() {
        while (eatCount < MAX_EAT_TIMES) {
            think();
            try {
                table.acquire(); // Kiểm soát số triết gia có thể vào bàn
                leftChopstick.acquire();
                System.out.println("Triết gia " + id + " đã lấy đũa bên trái.");

                rightChopstick.acquire();
                System.out.println("Triết gia " + id + " đã lấy đủ 2 đũa và bắt đầu ăn.");

                eat();

                leftChopstick.release();
                rightChopstick.release();
                table.release(); // Giải phóng quyền vào bàn ăn

                System.out.println("Triết gia " + id + " đã ăn xong và thả đũa.");

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("🎉 Triết gia " + id + " đã ăn đủ 5 lần và rời khỏi bàn!");
    }
}
