package bai1;

import java.util.concurrent.Semaphore;

public class DiningPhilosophers {
    public static void main(String[] args) {
        int numPhilosophers = 5;
        Semaphore[] chopsticks = new Semaphore[numPhilosophers];
        Semaphore table = new Semaphore(numPhilosophers - 1); // Tối đa 4 triết gia có thể vào bàn

        // Khởi tạo Semaphore cho từng đũa
        for (int i = 0; i < numPhilosophers; i++) {
            chopsticks[i] = new Semaphore(1);
        }

        // Tạo và chạy luồng cho từng triết gia
        Philosopher[] philosophers = new Philosopher[numPhilosophers];
        for (int i = 0; i < numPhilosophers; i++) {
            philosophers[i] = new Philosopher(i, chopsticks[i], chopsticks[(i + 1) % numPhilosophers], table);
            philosophers[i].start();
        }

        // Đợi tất cả triết gia ăn xong
        for (int i = 0; i < numPhilosophers; i++) {
            try {
                philosophers[i].join(); // Chờ luồng triết gia kết thúc
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("✅ Tất cả triết gia đã ăn xong 5 lần. Kết thúc chương trình!");
    }
}
